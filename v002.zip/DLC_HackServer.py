﻿import random
import time

path_version = '0.2'

def server_hack():
	class Hack_Server:
		password_1 = 'lPSFvDQBMCwS14GGQ3EcymTP3lfWcoz0LTh2$sElVjdbPgpDJuBVI'
		password_2 = 'SFowBvvhRETxsqKpqC4NBF6YMaKGA2xtb1pqKgFWrVZg33'
		password_3 = 'PzgY3PqhP59$XZ2a?sihhFozdnNM428OC6bQBXIj4xFmY'

	random_password_1 = 'lPSFvDQBMCwS14GGQ3EcymTP3lfWcoz0LTh2$sElVjdbPgpDJuBVI'
	random_password_2 = 'SFowBvvhRETxsqKpqC4NBF6YMaKGA2xtb1pqKgFWrVZg33'
	random_password_3 = 'PzgY3PqhP59$XZ2a?sihhFozdnNM428OC6bQBXIj4xFmY'

	rtp = int(random.randint(0, 2))
	if rtp == 0:
		server_password = random_password_1
	elif rtp == 1:
		server_password = random_password_2
	elif rtp == 2:
		server_password = random_password_3

	rt = random.randint(0, 10)

	pass_answer = Hack_Server.password_1
	if pass_answer != server_password:
		print('The password does not match, try another one...')
		time.sleep(rt)
		pass_answer = Hack_Server.password_2
		if pass_answer != server_password:
			print('The password does not match, try another one...')
			time.sleep(rt)
			pass_answer = Hack_Server.password_3
			if pass_answer == server_password:
				print('Hacking carried out.')
				print('Did they find your break-in? We will know in 10 seconds...')
			elif pass_answer != server_password:
				print('The server is too secure. The program will not be able to crack it automatically. You will have to do it manually')
				print('Did they find your break-in? We will know in 10 seconds...')
		elif pass_answer == server_password:
			print('Hacking carried out.')
			print('Did they find your break-in? We will know in 10 seconds...')
	elif pass_answer == server_password:
		print('Hacking carried out.')
		print('Did they find your break-in? We will know in 10 seconds...')
	return None
server_hack()